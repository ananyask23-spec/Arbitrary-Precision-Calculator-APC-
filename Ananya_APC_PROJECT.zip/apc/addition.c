
/*Name: Ananya S K
  Date: 29/10/2025
  Description: Arbitory precision calculator
*/


#include "apc.h"
#include<stdio.h>
#include<string.h>
#include<stdlib.h>


//converting string into integer value
void digit_to_list(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,char *argv[])
{
	//holds address of second argument
	char *str1=argv[1];
	int i, data;
     for(i=0;str1[i]!='\0';i++)
	 {
	 data=str1[i]-'0';
	 //crating list 1
	 dl_insert_last(head1, tail1, data);
	 } 

	 //holds address of 3rd argument
	 char *str2=argv[3];
     for(i=0;str2[i]!='\0';i++)
	 {
	 data=str2[i]-'0';
	 //crating list 2
	 dl_insert_last(head2, tail2, data);
	 }

}
int dl_insert_last(Dlist **head, Dlist **tail, int data)
{
	int var=0;
     
  Dlist *new;
  //dynamic memory allocation
  new=malloc(sizeof(Dlist));
  if(new==NULL)
  {
	return -1;
  }
  new->data=data;
  new->next=NULL;
  new->prev=NULL;
  if(new==NULL)
  return -1;
  //list is empty
  if(*head==NULL)
  {
      *head=new;
      *tail=new;
  }
  else
  {
	//updating newnode link with existing one
      new->prev=*tail;
      (*tail)->next=new;
      *tail=new;
      
  }
}

int dl_insert_first(Dlist **head, Dlist **tail, int data)
{
  Dlist *new;
  new=malloc(sizeof(Dlist));
  new->data=data;
  new->next=NULL;
  new->prev=NULL;
  if(new==NULL)
  return -1;
  //if list is empty
  //directly insert
  if(*head==NULL)
  {
      *head=new;
      *tail=new;
  }
  else
  {
	//updating newnode link with existing one
       new->next=*head;
      (*head)->prev=new;
       *head=new;
  }

}

void print_list(Dlist *head)
{
	/* Cheking the list is empty or not */
	if (head == NULL)
	{
		printf("INFO : List is empty\n");
	}
	else
	{
	    printf("Head -> ");
	    while (head)		
	    {
		    /* Printing the list */
		    printf("%d <-", head -> data);

		    /* Travering in forward direction */
		    head = head -> next;
		    if (head)
		        printf("> ");
	    }
    	printf(" Tail\n");
    }
}
int addition(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
	/* Definition goes here */
	Dlist *temp1=*tail1, *temp2=*tail2, *new;
	int data;
	int carry=0;
   while(temp1 || temp2)
   {
	
	//Example: List1 = 123, List2 = 456
	if(temp1!=NULL&&temp2!=NULL)
	{
		//carry if data is greaterthan 9
    data=temp1->data+temp2->data+carry;
	if(data>9)
	{
		/*List1 = 876
	      List2 = 754*/
	dl_insert_first(headR, tailR, data%10);
	carry=1;
	}
	else
	{
	 /*List1 = 123
	   List2 = 432*/
	dl_insert_first(headR, tailR, data);
	carry=0;
	}
    }

	//Example: List1 = 123, List2 = 45
	else if(temp1!=NULL&&temp2==NULL)
	{
    data=temp1->data +carry;

	
	if(data>9)
	{
		/*List1 = 958
          List2 = 73*/
	dl_insert_first(headR, tailR, data%10);
	carry=1;
	}
	
    else
	{
		/*List1 = 123;
		  List2 = 45;*/
	dl_insert_first(headR, tailR, data);
	carry=0;
	}
   }

   //Example: List1 = 45, List2 = 123
   else if(temp1==NULL&&temp2!=NULL)
	{
    data=temp2->data +carry;
	if(data>9)
	{
	 /*List1 = 76
	   List2 = 958*/
	dl_insert_first(headR, tailR, data%10);
	carry=1;
	}
	
    else
	{
		/*List1 = 12
		  List2 = 345*/
	dl_insert_first(headR, tailR, data);
	carry=0;
	}
   }

   if (temp1 != NULL)
        {
            temp1 = temp1->prev;
        }
   if (temp2 != NULL)
        {
            temp2 = temp2->prev;
        }     
   }

   //List1 = 999, List2 = 1
	if(carry==1)
	{
	dl_insert_first(headR, tailR, carry);
	carry=0;
	}
	return 0;
}

