#include "apc.h"
#include<stdio.h>
#include<stdlib.h>

int length_of_list_func(Dlist **head1, Dlist **head2)
{
	int list1_len=0;
	int list2_len=0;
	Dlist *temp1=*head1;
	Dlist *temp2=*head2;
	while(temp1!=NULL)
	{
		list1_len++;
		temp1=temp1->next;
	}
    while(temp2!=NULL)
	{
		list2_len++;
		temp2=temp2->next;
	}
	if(list1_len>list2_len)
	return 1;
	else if(list1_len<list2_len)
	return 0;
	else if(list1_len==list2_len)
	{
	   temp1=*head1;
	   temp2=*head2;

	   while(temp1!=NULL)
	   {
	   if(temp1->data>temp2->data)
	   return 1;
	   else if(temp1->data<temp2->data)
	   return 0;
	   else if(temp1->data==temp2->data)
        {
			temp1=temp1->next;
			temp2=temp2->next;
        }
	  }
		return -1;
	}
   
}
int subtraction(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist**tailR, int flag)
{
    Dlist *temp1 = *tail1, *temp2 = *tail2;
    int data;
    int borrow = 0;

    while (temp1||temp2)
    {
        if (temp1 != NULL && temp2 != NULL)
        {
         if(temp1->data>=temp2->data+borrow)
        {
            
                // list1 digit is enough, subtract directl
                data = temp1->data - temp2->data - borrow;
                borrow=0;
                
        }
            else
            {
                // need to borrow
                temp1->data = temp1->data + 10;
                data = temp1->data - temp2->data - borrow;
                borrow=1;
               
                
            }
            dl_insert_first(headR, tailR, data);
        }
        
       else if (temp1 != NULL && temp2 == NULL)
        {
            if (temp1->data >= borrow)
            {
                data = temp1->data - borrow;
                borrow = 0;
            }
            else
            {
                temp1->data =temp1->data+10;
                data = temp1->data - borrow;
                borrow = 1;
            }
            dl_insert_first(headR, tailR, data);
        }
        


        if(temp1!=NULL)
        temp1 = temp1->prev;
        if (temp2 != NULL)
            temp2 = temp2->prev;
}

// If flag is set, make the most significant digit negative
    if (flag == 1 && *headR != NULL)
    {
        (*headR)->data = (*headR)->data * -1;
    }
}
