#include "apc.h"
#include<stdio.h>
#include<stdlib.h>
#include<stdio.h>


int main(int argc, char *argv[])
{
	/* Declare the pointers */
      
	   Dlist *head1=NULL, *tail1=NULL;
        Dlist *head2=NULL, *tail2=NULL; 
        Dlist *headR=NULL,*tailR=NULL;


	char operator=argv[2][0];
    int flag=0, count, res;

		switch (operator)
		{
			case '+':
                                digit_to_list(&head1,&tail1,&head2,&tail2,argv);
				/* call the function to perform the addition operation */
                                addition(&head1,&tail1,&head2,&tail2,&headR,&tailR);
								print_list(headR);
				break;
			case '-':	
				/* call the function to perform the subtraction operation */
				digit_to_list(&head1,&tail1,&head2,&tail2,argv);
				int ret1=length_of_list_func(&head1, &head2);
				if(ret1==1)
				{
					subtraction(&head1, &tail1, &head2, &tail2, &headR, &tailR, flag);
				}
				else if(ret1==0)
				{
					flag=1;
					subtraction(&head2, &tail2, &head1, &tail1, &headR, &tailR, flag);
				}
				else
				{
					dl_insert_first(&headR, &tailR, 0);
				}
				
                print_list(headR);
				
				break;
			case 'x':	
			    digit_to_list(&head1,&tail1,&head2,&tail2,argv);
				multiplication(&head1, &tail1, &head2, &tail2, &headR, &tailR);
				printf("multiplication done\n");
				print_list(headR);
				break;
			case '/':	
				/* call the function to perform the division operation */
				digit_to_list(&head1,&tail1,&head2,&tail2,argv);
			    res=division(&head1, &tail1, &head2, &tail2, &headR, &tailR);
				printf("%d\n", res);

				break;
			default:
				printf("Invalid Input:-( Try again...\n");
		}
	return 0;
}
