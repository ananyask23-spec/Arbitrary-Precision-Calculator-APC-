#include "apc.h"
#include<stdio.h>
#include<stdlib.h>

volatile int flag;

//function to delete list
int dl_delete_list(Dlist **head, Dlist **tail)
{

Dlist *temp;
temp=*head;
//list empty
    if(*head==NULL)
    return -1;
	//traverse till last node to delete list
	while(temp!=NULL)
	{
	    *head=temp->next;
	     free(temp);
	     temp=*head;
	}
	*head=NULL;
	*tail=NULL;
	return 0;
}
//function to compare the data
int compare_lists(Dlist **head1, Dlist **head2)
{
    int list1_len=0;
	int list2_len=0;

	Dlist *temp1=*head1;
	Dlist *temp2=*head2;
	while(temp1!=NULL)
	{
		list1_len++;//length of list 1
		temp1=temp1->next;
	}
    while(temp2!=NULL)
	{
		list2_len++;//length of list 2
		temp2=temp2->next;
	}

	//comparing length of two lists
	if(list1_len>list2_len)
	return 1;
	else if(list1_len<list2_len)
	return 0;
	else if(list1_len==list2_len)
	{
	   temp1=*head1;
	   temp2=*head2;

	   while(temp1!=NULL)
	   {
		//comparing data of two lists
	   if(temp1->data>temp2->data)
	   return 1;
	   else if(temp1->data<temp2->data)
	   return 0;
	   else if(temp1->data==temp2->data)
        {
			temp1=temp1->next;
			temp2=temp2->next;
        }
	  }
		return -1;
	}
}

//function two perform divison
int division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    int count = 0;

    while (1) 
    {
        // Remove leading zeros 
        while (*head1 && (*head1)->data == 0)
        {
            Dlist *tmp = *head1;
            *head1 = (*head1)->next;
			//if head1 address is not NULL means
            if (*head1) 
			(*head1)->prev = NULL;
            free(tmp);
        }
        //if (*head1 == NULL) break;

        
        int cmp = compare_lists(head1, head2);
		//if list<list2
        if (cmp == 0) 
		break;   
		//if list 1>list 2  
        if (cmp == -1)           
        {
			//increement count whenever subtraction is called
            count++;
            break;
        }

        //calll subtraction till list1 is less than list2
        subtraction(head1, tail1, head2, tail2, headR, tailR, 0);

        //delete head1, tail1 and updata with headR and tailR
        dl_delete_list(head1, tail1);
        *head1 = *headR;
        *tail1 = *tailR;
        *headR = *tailR = NULL;
        count++;
    }

	//result of subtraction
    return count;
}
