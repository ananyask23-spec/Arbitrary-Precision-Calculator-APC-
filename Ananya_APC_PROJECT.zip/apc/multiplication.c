#include "apc.h"
#include<stdio.h>
#include<stdlib.h>

//function To perform multiplication
int multiplication(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    Dlist *temp1, *temp2;
    Dlist *headR1 = NULL, *tailR1 = NULL;
    Dlist *headR2 = NULL, *tailR2 = NULL;
    int count = 0, carry, res;

    temp2 = *tail2;

    while(temp2 != NULL)
    {
        // add zeros for place value
        for(int i = 0; i < count; i++)
            dl_insert_first(&headR2, &tailR2, 0);

        temp1 = *tail1;
        carry = 0;
        while(temp1 != NULL)
        {
            res = temp1->data * temp2->data + carry;
            dl_insert_first(&headR2, &tailR2, res % 10);
            carry = res / 10;
            temp1 = temp1->prev;
        }
		 if(carry > 0)
            dl_insert_first(&headR2, &tailR2, carry);

        // Reset headR and tailR before addition
        *headR = NULL;
        *tailR = NULL;
        
        // If first iteration, just copy headR2 to headR1 (don't use addition)
        if (headR1 == NULL)
         {
            headR1 = headR2;
            tailR1 = tailR2;
            headR2 = NULL;
            tailR2 = NULL;
        }
         else 
        {
            // add partial product to cumulative sum
            addition(&headR1, &tailR1, &headR2, &tailR2, headR, tailR);

            // update cumulative sum
            headR1 = *headR;
            tailR1 = *tailR;
			 // delete temporary product
            dl_delete_list(&headR2, &tailR2);
        }

        count++;
        temp2 = temp2->prev;
    }
    
    // Final result in headR1 and tailR1
    *headR = headR1;
    *tailR = tailR1;
	return 0;
}

